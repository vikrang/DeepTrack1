"""Instrument registry for the Indian market.

One definition drives the web forms, API validation, the investments table and
the Excel template, so all four stay in sync.
"""

from .validators import parse_date, parse_number

CATEGORIES = [
    {"key": "equity", "label": "Equity", "tagline": "Stocks, mutual funds, ETFs", "color": "#6366f1"},
    {"key": "debt", "label": "Debt", "tagline": "FDs, bonds, PPF, NPS, EPF", "color": "#0ea5e9"},
    {"key": "other", "label": "Other assets", "tagline": "Property, gold, crypto, insurance", "color": "#f59e0b"},
]

EXCHANGES = ["NSE", "BSE"]
PLANS = ["Direct", "Regular"]
MF_OPTIONS = ["Growth", "IDCW - Payout", "IDCW - Reinvestment"]
COMPOUNDING = ["Quarterly", "Monthly", "Half-yearly", "Annual", "Simple"]
SUMMARY_FREQUENCIES = ["Annual", "Semi-annual", "Quarterly", "Cumulative"]
ACCOUNT_TYPES = ["Savings", "Salary", "Current", "NRE", "NRO", "Jan Dhan"]

BANKS = [
    "State Bank of India", "HDFC Bank", "ICICI Bank", "Axis Bank", "Kotak Mahindra Bank",
    "Punjab National Bank", "Bank of Baroda", "Canara Bank", "Union Bank of India",
    "IDFC FIRST Bank", "Yes Bank", "IndusInd Bank", "Federal Bank", "South Indian Bank",
    "Indian Bank", "Central Bank of India", "Bank of Maharashtra", "AU Small Finance Bank",
    "Bandhan Bank", "India Post Payments Bank", "Other",
]

AMCS = [
    "SBI Mutual Fund", "HDFC Mutual Fund", "ICICI Prudential MF", "Nippon India MF",
    "Axis Mutual Fund", "Kotak Mahindra MF", "UTI Mutual Fund", "Aditya Birla Sun Life MF",
    "Mirae Asset MF", "Parag Parikh MF", "Quant MF", "DSP MF", "Franklin Templeton MF",
    "Tata MF", "Motilal Oswal MF", "Edelweiss MF", "Invesco MF", "HSBC MF",
    "Bandhan MF", "Sundaram MF", "Navi MF", "WhiteOak MF", "Other",
]

MF_CATEGORIES = [
    "Large Cap", "Mid Cap", "Small Cap", "Flexi Cap", "Multi Cap", "Focused Fund",
    "ELSS (Tax Saving)", "Index Fund", "Sectoral / Thematic", "Balanced Advantage",
    "Aggressive Hybrid", "Conservative Hybrid", "Arbitrage", "Liquid", "Overnight",
    "Ultra Short Duration", "Corporate Bond", "Gilt", "Credit Risk", "Gold",
    "International / Fund of Funds", "Other",
]

SECTORS = [
    "Banking & Financial Services", "Information Technology", "Oil & Gas", "FMCG",
    "Pharmaceuticals", "Automobile", "Metals & Mining", "Power & Utilities", "Telecom",
    "Construction & Realty", "Capital Goods", "Chemicals", "Consumer Durables", "Cement",
    "Infrastructure", "Textiles", "Media & Entertainment", "Diversified", "Other",
]

BROKERS = [
    "Zerodha", "Groww", "Upstox", "ICICI Direct", "HDFC Securities", "Kotak Securities",
    "Angel One", "Motilal Oswal", "Sharekhan", "5paisa", "Axis Direct", "SBI Securities",
    "Dhan", "INDmoney", "Other",
]

REGISTRARS = ["CAMS", "KFintech", "Franklin Templeton (in-house)", "Other"]

BOND_KINDS = [
    "Government Security (G-Sec)", "Treasury Bill", "State Development Loan",
    "Corporate Bond", "Tax-Free Bond", "Sovereign Gold Bond", "Debenture", "Other",
]

CREDIT_RATINGS = ["Sovereign", "AAA", "AA+", "AA", "AA-", "A+", "A", "BBB+", "BBB", "Unrated"]

SMALL_SAVINGS = [
    "National Savings Certificate (NSC)", "Kisan Vikas Patra (KVP)", "Post Office MIS",
    "Sukanya Samriddhi Yojana (SSY)", "Senior Citizens' Savings Scheme (SCSS)",
    "Post Office Time Deposit", "Other",
]

PENSION_FUNDS = [
    "SBI Pension Funds", "LIC Pension Fund", "UTI Retirement Solutions", "HDFC Pension",
    "ICICI Prudential Pension", "Kotak Mahindra Pension", "Aditya Birla Pension",
    "Tata Pension", "Max Life Pension", "DSP Pension",
]

INSURERS = [
    "LIC of India", "HDFC Life", "ICICI Prudential Life", "SBI Life", "Max Life",
    "Bajaj Allianz Life", "Tata AIA Life", "Kotak Life", "Aditya Birla Sun Life Insurance",
    "Axis Max Life", "PNB MetLife", "Star Health", "Niva Bupa", "Care Health",
    "New India Assurance", "ICICI Lombard", "HDFC ERGO", "Bajaj Allianz General",
    "United India Insurance", "Other",
]

PROPERTY_TYPES = [
    "Residential Apartment", "Independent House / Villa", "Plot / Land",
    "Commercial Office", "Shop / Retail", "Industrial / Warehouse", "Agricultural Land",
]

METALS = ["Gold", "Silver", "Platinum", "Diamond", "Other"]
PURITIES = ["24K", "22K", "18K", "14K", "925 Silver", "Other"]
HALLMARKS = ["BIS Hallmarked", "Certified (IGI / GIA)", "Non-hallmarked", "Not sure"]
STORAGE = ["Bank locker", "Home safe", "With family", "Other"]

CRYPTO_COINS = [
    "Bitcoin (BTC)", "Ethereum (ETH)", "Tether (USDT)", "BNB", "Solana (SOL)", "XRP",
    "Cardano (ADA)", "Dogecoin (DOGE)", "Polygon (MATIC)", "Avalanche (AVAX)",
    "Chainlink (LINK)", "Other",
]

CRYPTO_PLATFORMS = [
    "WazirX", "CoinDCX", "CoinSwitch", "Binance", "ZebPay", "Giottus", "Mudrex",
    "Ledger (self-custody)", "MetaMask (self-custody)", "Other",
]

POLICY_TYPES = [
    "Term Life", "Endowment", "ULIP", "Money Back", "Whole Life", "Health",
    "Critical Illness", "Personal Accident",
]

PREMIUM_FREQUENCIES = ["Monthly", "Quarterly", "Half-yearly", "Annual", "Single premium"]


def f(key, label, input="text", **extra):
    field = {"key": key, "label": label, "input": input}
    field.update({k: v for k, v in extra.items() if v is not None})
    return field


_TYPES = [
    {
        "key": "stocks",
        "label": "Direct stocks",
        "category": "equity",
        "sheet": "Equity - Stocks",
        "blurb": "Listed shares held in a demat account",
        "name_label": "Company name",
        "name_placeholder": "e.g. Reliance Industries",
        "invested_label": "Amount invested",
        "value_label": "Current value",
        "derive": {"invested": ("quantity", "avg_buy_price"), "value": ("quantity", "ltp")},
        "fields": [
            f("symbol", "Symbol / ticker", required=True, table=True, placeholder="RELIANCE"),
            f("exchange", "Exchange", "select", options=EXCHANGES, required=True, default="NSE"),
            f("quantity", "Quantity", "number", required=True, table=True, min=0),
            f("avg_buy_price", "Average buy price", "number", unit="₹", required=True, table=True, min=0),
            f("ltp", "Current price (LTP)", "number", unit="₹", min=0),
            f("sector", "Sector", "select", options=SECTORS),
            f("broker", "Broker / DP", "select", options=BROKERS),
            f("demat_account", "Demat / client ID", placeholder="NSDL or CDSL client ID"),
            f("isin", "ISIN", placeholder="INE002A01018"),
        ],
    },
    {
        "key": "mutual_funds",
        "label": "Mutual funds",
        "category": "equity",
        "sheet": "Equity - Mutual Funds",
        "blurb": "SIP and lump-sum folios with any AMC",
        "name_label": "Scheme name",
        "name_placeholder": "e.g. Parag Parikh Flexi Cap Fund",
        "invested_label": "Amount invested",
        "value_label": "Current value",
        "derive": {"invested": ("units", "avg_nav"), "value": ("units", "current_nav")},
        "fields": [
            f("amc", "AMC", "select", options=AMCS, required=True),
            f("scheme_category", "Scheme category", "select", options=MF_CATEGORIES, required=True),
            f("plan", "Plan", "select", options=PLANS, required=True, default="Direct"),
            f("option", "Option", "select", options=MF_OPTIONS, required=True, default="Growth"),
            f("folio_no", "Folio number", placeholder="e.g. 123456789 / 0"),
            f("units", "Units held", "number", table=True, min=0),
            f("avg_nav", "Average NAV", "number", unit="₹", min=0),
            f("current_nav", "Current NAV", "number", unit="₹", min=0),
            f("sip_amount", "SIP amount (per month)", "number", unit="₹", min=0),
            f("sip_date", "SIP debit day", "number", min=1, max=31, help="Day of the month (1-31)"),
            f("registrar", "Registrar", "select", options=REGISTRARS),
        ],
    },
    {
        "key": "etf",
        "label": "ETFs",
        "category": "equity",
        "sheet": "Equity - ETFs",
        "blurb": "Exchange traded funds such as Nifty or gold ETFs",
        "name_label": "ETF name",
        "name_placeholder": "e.g. Nippon India Nifty 50 BeES",
        "invested_label": "Amount invested",
        "value_label": "Current value",
        "derive": {"invested": ("units", "avg_price"), "value": ("units", "current_price")},
        "fields": [
            f("symbol", "Symbol / ticker", required=True, table=True, placeholder="NIFTYBEES"),
            f("exchange", "Exchange", "select", options=EXCHANGES, required=True, default="NSE"),
            f("units", "Units held", "number", required=True, table=True, min=0),
            f("avg_price", "Average buy price", "number", unit="₹", required=True, min=0),
            f("current_price", "Current price", "number", unit="₹", min=0),
            f("underlying", "Tracks", "select", options=[
                "Nifty 50", "Nifty Next 50", "Bank Nifty", "Nifty Midcap 150", "Gold",
                "Silver", "International", "Other"]),
            f("broker", "Broker / DP", "select", options=BROKERS),
            f("demat_account", "Demat / client ID"),
        ],
    },
    {
        "key": "fd",
        "label": "Fixed deposits",
        "category": "debt",
        "sheet": "Debt - Fixed Deposits",
        "blurb": "Bank, NBFC and post office fixed deposits",
        "name_label": "Deposit name",
        "name_placeholder": "e.g. SBI 3-year FD",
        "invested_label": "Principal deposited",
        "value_label": "Current value",
        "derive": {"invested": ("principal",)},
        "fields": [
            f("bank", "Bank / NBFC", "select", options=BANKS, required=True),
            f("account_no", "FD account / receipt no.", placeholder="e.g. 3270456123"),
            f("principal", "Principal", "number", unit="₹", required=True, table=True, min=0),
            f("interest_rate", "Interest rate", "number", unit="%", required=True, table=True, min=0, max=20),
            f("tenure_months", "Tenure (months)", "number", min=1, max=600),
            f("compounding", "Compounding", "select", options=COMPOUNDING, default="Quarterly"),
            f("payout", "Interest payout", "select", options=["Cumulative", "Monthly", "Quarterly", "Annual"]),
            f("maturity_date", "Maturity date", "date"),
            f("nominee", "Nominee"),
            f("senior_citizen", "Senior citizen account", "boolean"),
        ],
    },
    {
        "key": "rd",
        "label": "Recurring deposits",
        "category": "debt",
        "sheet": "Debt - Recurring Deposits",
        "blurb": "Monthly deposit schemes at banks and post offices",
        "name_label": "Deposit name",
        "name_placeholder": "e.g. HDFC 5-year RD",
        "invested_label": "Total deposited",
        "value_label": "Current value",
        "fields": [
            f("bank", "Bank / post office", "select", options=BANKS, required=True),
            f("account_no", "RD account number"),
            f("monthly_amount", "Monthly deposit", "number", unit="₹", required=True, table=True, min=0),
            f("interest_rate", "Interest rate", "number", unit="%", required=True, min=0, max=20),
            f("tenure_months", "Tenure (months)", "number", required=True, min=1, max=600),
            f("maturity_date", "Maturity date", "date"),
            f("nominee", "Nominee"),
        ],
    },
    {
        "key": "bonds",
        "label": "Bonds & G-Secs",
        "category": "debt",
        "sheet": "Debt - Bonds",
        "blurb": "Government securities, corporate bonds, SGBs",
        "name_label": "Bond / security name",
        "name_placeholder": "e.g. 7.18% GOI 2033",
        "invested_label": "Amount invested",
        "value_label": "Current value",
        "derive": {"invested": ("quantity", "purchase_price")},
        "fields": [
            f("issuer", "Issuer", required=True, placeholder="Government of India / company"),
            f("bond_kind", "Bond type", "select", options=BOND_KINDS, required=True),
            f("isin", "ISIN", placeholder="IN0020230085"),
            f("quantity", "Units / quantity", "number", table=True, min=0),
            f("purchase_price", "Purchase price per unit", "number", unit="₹", min=0),
            f("face_value", "Face value per unit", "number", unit="₹", min=0),
            f("coupon_rate", "Coupon rate", "number", unit="%", table=True, min=0, max=30),
            f("maturity_date", "Maturity date", "date"),
            f("credit_rating", "Credit rating", "select", options=CREDIT_RATINGS),
            f("interest_frequency", "Interest frequency", "select", options=SUMMARY_FREQUENCIES),
            f("taxable", "Interest is taxable", "boolean"),
        ],
    },
    {
        "key": "ppf",
        "label": "PPF",
        "category": "debt",
        "sheet": "Debt - PPF",
        "blurb": "Public Provident Fund accounts",
        "name_label": "PPF account name",
        "name_placeholder": "e.g. PPF - SBI Nariman Point",
        "invested_label": "Total contributed",
        "value_label": "Current balance",
        "fields": [
            f("institution", "Bank / post office", "select", options=["India Post", *BANKS], required=True),
            f("account_no", "PPF account number", required=True),
            f("yearly_contribution", "Yearly contribution", "number", unit="₹", table=True, min=0, max=150000),
            f("interest_rate", "Interest rate", "number", unit="%", min=0, max=20),
            f("nominee", "Nominee"),
        ],
    },
    {
        "key": "epf",
        "label": "EPF / VPF",
        "category": "debt",
        "sheet": "Debt - EPF",
        "blurb": "Employee provident fund balances",
        "name_label": "EPF account name",
        "name_placeholder": "e.g. EPF - Infosys",
        "invested_label": "Total contributions",
        "value_label": "Current balance",
        "derive": {"invested": ["employee_contribution", "employer_contribution"]},
        "fields": [
            f("uan", "UAN", required=True, placeholder="12-digit Universal Account Number"),
            f("employer", "Employer / establishment", placeholder="e.g. Infosys Ltd"),
            f("employee_contribution", "Employee contribution", "number", unit="₹", min=0),
            f("employer_contribution", "Employer contribution", "number", unit="₹", min=0),
            f("interest_rate", "Interest rate", "number", unit="%", min=0, max=20),
        ],
    },
    {
        "key": "nps",
        "label": "NPS",
        "category": "debt",
        "sheet": "Debt - NPS",
        "blurb": "National Pension System Tier I and II",
        "name_label": "NPS account name",
        "name_placeholder": "e.g. NPS Tier I - SBI Pension",
        "invested_label": "Total contributed",
        "value_label": "Current corpus",
        "fields": [
            f("pran", "PRAN", required=True, placeholder="12-digit PRAN"),
            f("tier", "Tier", "select", options=["Tier I", "Tier II"], required=True, default="Tier I"),
            f("scheme_preference", "Scheme preference", "select", options=[
                "Active", "Auto", "Aggressive (LC75)", "Moderate (LC50)", "Conservative (LC25)"]),
            f("fund_manager", "Pension fund manager", "select", options=PENSION_FUNDS),
            f("employer_contribution", "Employer contribution", "number", unit="₹", min=0),
            f("annuity_pct", "Annuity allocation", "number", unit="%", min=0, max=100),
            f("retirement_date", "Retirement date", "date"),
        ],
    },
    {
        "key": "small_savings",
        "label": "Small savings",
        "category": "debt",
        "sheet": "Debt - Small Savings",
        "blurb": "NSC, KVP, SSY, SCSS and post office MIS",
        "name_label": "Scheme name",
        "name_placeholder": "e.g. NSC 2020 Series",
        "invested_label": "Amount deposited",
        "value_label": "Current value",
        "derive": {"invested": ("deposit_amount",)},
        "fields": [
            f("scheme", "Scheme", "select", options=SMALL_SAVINGS, required=True),
            f("institution", "Institution", "select", options=["India Post", *BANKS], required=True),
            f("account_no", "Account / certificate number"),
            f("deposit_amount", "Deposit amount", "number", unit="₹", table=True, min=0),
            f("interest_rate", "Interest rate", "number", unit="%", min=0, max=20),
            f("maturity_date", "Maturity date", "date"),
            f("nominee", "Nominee"),
        ],
    },
    {
        "key": "real_estate",
        "label": "Real estate",
        "category": "other",
        "sheet": "Other - Real Estate",
        "blurb": "Homes, plots and commercial property",
        "name_label": "Property name",
        "name_placeholder": "e.g. 3BHK Whitefield apartment",
        "invested_label": "Purchase price",
        "value_label": "Current valuation",
        "fields": [
            f("property_type", "Property type", "select", options=PROPERTY_TYPES, required=True),
            f("address", "Address", wide=True, placeholder="Building, street, locality"),
            f("city", "City", placeholder="e.g. Bengaluru"),
            f("area_sqft", "Area (sq ft)", "number", table=True, min=0),
            f("registration_charges", "Stamp duty & registration", "number", unit="₹", min=0),
            f("ownership_pct", "Ownership share", "number", unit="%", min=0, max=100, table=True),
            f("co_owner", "Co-owner"),
            f("loan_outstanding", "Home loan outstanding", "number", unit="₹", min=0),
            f("monthly_rent", "Monthly rent received", "number", unit="₹", min=0),
            f("survey_no", "Khata / survey number"),
            f("is_rented", "Currently rented", "boolean"),
        ],
    },
    {
        "key": "jewellery",
        "label": "Jewellery & bullion",
        "category": "other",
        "sheet": "Other - Jewellery",
        "blurb": "Physical gold, silver and diamonds",
        "name_label": "Item description",
        "name_placeholder": "e.g. Gold necklace set",
        "invested_label": "Purchase cost",
        "value_label": "Current valuation",
        "fields": [
            f("metal", "Metal", "select", options=METALS, required=True),
            f("purity", "Purity", "select", options=PURITIES, required=True),
            f("weight_grams", "Weight (grams)", "number", table=True, min=0),
            f("jeweller", "Jeweller / source"),
            f("bill_no", "Bill / invoice number"),
            f("hallmark", "Hallmarking", "select", options=HALLMARKS),
            f("storage", "Stored at", "select", options=STORAGE),
        ],
    },
    {
        "key": "crypto",
        "label": "Crypto assets",
        "category": "other",
        "sheet": "Other - Crypto",
        "blurb": "Coins and tokens held on exchanges or wallets",
        "name_label": "Holding name",
        "name_placeholder": "e.g. Bitcoin - WazirX",
        "invested_label": "Amount invested",
        "value_label": "Current value",
        "derive": {"invested": ("quantity", "avg_buy_price"), "value": ("quantity", "current_price")},
        "fields": [
            f("coin", "Coin / token", "select", options=CRYPTO_COINS, required=True),
            f("platform", "Exchange / wallet", "select", options=CRYPTO_PLATFORMS, required=True),
            f("quantity", "Quantity", "number", required=True, table=True, min=0),
            f("avg_buy_price", "Average buy price", "number", unit="₹", required=True, min=0),
            f("current_price", "Current price", "number", unit="₹", min=0),
            f("wallet_address", "Wallet address", wide=True, placeholder="Optional, for self-custody holdings"),
        ],
    },
    {
        "key": "insurance",
        "label": "Insurance policies",
        "category": "other",
        "sheet": "Other - Insurance",
        "blurb": "Life, health and ULIP policies",
        "name_label": "Policy / plan name",
        "name_placeholder": "e.g. LIC Jeevan Anand",
        "invested_label": "Premiums paid",
        "value_label": "Current fund value",
        "fields": [
            f("insurer", "Insurer", "select", options=INSURERS, required=True),
            f("policy_type", "Policy type", "select", options=POLICY_TYPES, required=True),
            f("policy_no", "Policy number", required=True),
            f("sum_assured", "Sum assured", "number", unit="₹", table=True, min=0),
            f("premium_amount", "Premium amount", "number", unit="₹", min=0),
            f("premium_frequency", "Premium frequency", "select", options=PREMIUM_FREQUENCIES),
            f("policy_term_years", "Policy term (years)", "number", min=1, max=100),
            f("maturity_date", "Maturity date", "date"),
            f("fund_value", "Fund / surrender value", "number", unit="₹", min=0),
            f("nominee", "Nominee"),
        ],
    },
]

TYPES = {t["key"]: t for t in _TYPES}
TYPE_LIST = _TYPES
SHEETS = {t["sheet"]: t["key"] for t in _TYPES}
CATEGORY_MAP = {c["key"]: c for c in CATEGORIES}

COMMON_FIELDS = [
    {"key": "name", "label": "Investment name", "input": "text", "required": True, "wide": True},
    {"key": "invested_amount", "label": "Amount invested", "input": "number", "unit": "₹", "required": True},
    {"key": "current_value", "label": "Current value", "input": "number", "unit": "₹", "required": True},
    {"key": "start_date", "label": "Purchase / start date", "input": "date"},
    {"key": "notes", "label": "Notes", "input": "text", "wide": True},
]


def meta() -> dict:
    """Payload that lets the frontend render every form and table column."""
    types = []
    for type_meta in _TYPES:
        item = dict(type_meta)
        if item.get("derive"):
            item["derive"] = {
                target: {"op": "mul" if isinstance(spec, tuple) else "sum", "fields": list(spec)}
                for target, spec in item["derive"].items()
            }
        types.append(item)
    return {
        "categories": CATEGORIES,
        "types": types,
        "common_fields": COMMON_FIELDS,
        "banks": BANKS,
        "account_types": ACCOUNT_TYPES,
        "currency": "INR",
    }


def table_fields(type_key: str) -> list[str]:
    return [fld["key"] for fld in TYPES[type_key]["fields"] if fld.get("table")]


def _canonical_option(options: list[str], value: str):
    lookup = {opt.lower(): opt for opt in options}
    return lookup.get(str(value).strip().lower())


_TRUE = {"yes", "y", "true", "1", "ja", "haan"}
_FALSE = {"no", "n", "false", "0", "nahi"}


def _parse_boolean(value):
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in _TRUE:
        return True
    if text in _FALSE:
        return False
    raise ValueError("Choose Yes or No")


def _derive_values(type_meta: dict, details: dict) -> tuple:
    invested = value = None
    rules = type_meta.get("derive") or {}
    for target, spec in rules.items():
        if isinstance(spec, tuple) and len(spec) == 2:
            first, second = (details.get(spec[0]), details.get(spec[1]))
            if isinstance(first, (int, float)) and isinstance(second, (int, float)):
                result = first * second
            else:
                result = None
        else:
            parts = [details.get(k) for k in spec]
            if all(isinstance(p, (int, float)) for p in parts) and parts:
                result = sum(parts)
            else:
                result = None
        if target == "invested":
            invested = result
        elif target == "value":
            value = result
    return invested, value


def validate_investment(payload: dict) -> tuple[dict, dict]:
    """Return (cleaned, errors). cleaned['data'] is safe to persist."""
    errors: dict[str, str] = {}
    type_key = (payload.get("type") or "").strip()
    type_meta = TYPES.get(type_key)
    if not type_meta:
        return {}, {"type": "Choose a valid investment type"}

    parsed = {}
    details = {}
    for field in type_meta["fields"]:
        raw = payload.get(field["key"])
        key = field["key"]
        kind = field["input"]
        try:
            if kind == "number":
                value = parse_number(raw)
                if value is not None:
                    if field.get("min") is not None and value < field["min"]:
                        raise ValueError(f"Must be at least {field['min']}")
                    if field.get("max") is not None and value > field["max"]:
                        raise ValueError(f"Must be at most {field['max']}")
            elif kind == "date":
                value = parse_date(raw)
            elif kind == "select":
                if raw is None or str(raw).strip() == "":
                    value = None
                else:
                    value = _canonical_option(field.get("options", []), raw)
                    if value is None:
                        raise ValueError("Choose one of the listed options")
            elif kind == "boolean":
                value = _parse_boolean(raw)
            else:
                if raw is None:
                    value = None
                else:
                    value = str(raw).strip()
                    if value == "":
                        value = None
                    elif len(value) > 300:
                        raise ValueError("Too long (max 300 characters)")
            if field.get("required") and value is None:
                raise ValueError("This field is required")
            parsed[key] = value
        except ValueError as exc:
            errors[key] = str(exc)
            parsed[key] = None
    details = {k: v for k, v in parsed.items() if v is not None}

    name = str(payload.get("name") or "").strip()
    if not name:
        errors["name"] = "Give this investment a name"
    elif len(name) > 160:
        errors["name"] = "Keep the name under 160 characters"

    notes = str(payload.get("notes") or "").strip()
    if len(notes) > 2000:
        errors["notes"] = "Notes are limited to 2000 characters"

    try:
        start_date = parse_date(payload.get("start_date"))
    except ValueError as exc:
        errors["start_date"] = str(exc)
        start_date = None

    maturity_raw = details.get("maturity_date")
    if start_date and maturity_raw and maturity_raw < start_date:
        errors["maturity_date"] = "Maturity cannot be before the start date"

    derived_invested, derived_value = _derive_values(type_meta, details)
    try:
        invested = parse_number(payload.get("invested_amount"))
    except ValueError as exc:
        errors["invested_amount"] = str(exc)
        invested = None
    if invested is None:
        invested = derived_invested
    if invested is None:
        errors["invested_amount"] = "Enter the amount invested (or the fields needed to compute it)"

    try:
        current = parse_number(payload.get("current_value"))
    except ValueError as exc:
        errors["current_value"] = str(exc)
        current = None
    if current is None:
        current = derived_value
    if current is None:
        current = invested

    try:
        owner_id = int(payload.get("owner_id"))
    except (TypeError, ValueError):
        owner_id = None
        errors["owner_id"] = "Choose who owns this investment"

    if invested is not None and invested < 0:
        errors["invested_amount"] = "Amount cannot be negative"
    if current is not None and current < 0:
        errors["current_value"] = "Value cannot be negative"

    data = {
        "owner_id": owner_id,
        "type": type_key,
        "category": type_meta["category"],
        "name": name,
        "invested_amount": round(invested, 2) if invested is not None else 0,
        "current_value": round(current, 2) if current is not None else 0,
        "start_date": start_date,
        "notes": notes or None,
        "details": details,
    }
    return data, errors
