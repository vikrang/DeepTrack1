"""Excel template generation, import parsing and portfolio export."""

import io
import re
from datetime import date, datetime

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from . import fields

CATEGORY_COLORS = {c["key"]: c["color"].lstrip("#") for c in fields.CATEGORIES}
HEADER_FILL = "1E293B"
MUTED = "64748B"
INR_FORMAT = '"₹ "#,##,##0.00'
PERCENT_FORMAT = '0.00"%"'
DATE_FORMAT = "DD-MMM-YYYY"
MAX_IMPORT_ROWS = 5000

COMMON_EXCEL = [
    ("invested_amount", "Amount invested", "number"),
    ("current_value", "Current value", "number"),
    ("start_date", "Purchase / start date", "date"),
    ("notes", "Notes", "text"),
]

ALIASES = {
    "owner": "owner_email",
    "owner mail": "owner_email",
    "owner id": "owner_email",
    "member": "owner_email",
    "member email": "owner_email",
    "email": "owner_email",
    "amount": "invested_amount",
    "invested": "invested_amount",
    "amount invested": "invested_amount",
    "current": "current_value",
    "current val": "current_value",
    "start": "start_date",
    "purchase date": "start_date",
    "purchase start date": "start_date",
    "date of purchase": "start_date",
}


def _norm(value) -> str:
    text = str(value or "").lower().replace("₹", " ")
    text = re.sub(r"\(.*?\)", " ", text).replace("*", " ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return text.strip()


def _header(field, unit_override=None) -> str:
    label = field["label"]
    unit = unit_override or field.get("unit")
    if unit:
        label += f" ({unit})"
    if field.get("required"):
        label += " *"
    return label


def _sheet_title(type_meta) -> str:
    return type_meta["sheet"]


def _collect_lists():
    """Unique dropdown lists referenced by data validation."""
    lists = []
    seen = {}
    list_for_field = {}

    def add(options):
        key = tuple(options)
        if not key:
            return None
        if key not in seen:
            seen[key] = f"List{len(lists) + 1}"
            lists.append({"key": seen[key], "options": list(options)})
        return seen[key]

    for type_meta in fields.TYPE_LIST:
        for field in type_meta["fields"]:
            if field["input"] == "select":
                list_for_field[(type_meta["key"], field["key"])] = add(field["options"])
            elif field["input"] == "boolean":
                list_for_field[(type_meta["key"], field["key"])] = add(["Yes", "No"])
    return lists, list_for_field


def _style_header(cell, color):
    cell.font = Font(bold=True, color="FFFFFF", size=10)
    cell.fill = PatternFill("solid", fgColor=color)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = Border(bottom=Side(style="thin", color="CBD5E1"))
    cell.font = Font(bold=True, color="FFFFFF", size=10)


def _add_comment(cell, text):
    if not text:
        return
    comment = Comment(text, "DeepTrack")
    comment.width = 280
    comment.height = 110
    cell.comment = comment


def _write_sheet(wb, type_meta, list_ranges, list_for_field, rows=None):
    """rows: list of dicts {name, details, invested_amount, current_value, start_date, notes, owner_email}"""
    ws = wb.create_sheet(_sheet_title(type_meta))
    ws.sheet_properties.tabColor = CATEGORY_COLORS[type_meta["category"]]
    headers = [("name", "Investment name", "text")]
    for field in type_meta["fields"]:
        headers.append((field["key"], _header(field), field["input"]))
    for key, label, kind in COMMON_EXCEL:
        if key == "invested_amount":
            label = type_meta.get("invested_label", "Amount invested")
            headers.append((key, f"{label} (₹)", "number"))
        elif key == "current_value":
            label = type_meta.get("value_label", "Current value")
            headers.append((key, f"{label} (₹)", "number"))
        else:
            headers.append((key, label, kind))
    headers.append(("owner_email", "Owner email", "text"))

    for col, (key, label, kind) in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=label)
        _style_header(cell, CATEGORY_COLORS[type_meta["category"]])
        field_meta = next((f for f in type_meta["fields"] if f["key"] == key), None)
        if field_meta and field_meta.get("help"):
            _add_comment(cell, field_meta["help"])
        elif field_meta and field_meta["input"] == "select":
            _add_comment(cell, "Options: " + ", ".join(field_meta["options"]))
        elif key == "owner_email":
            _add_comment(cell, "Email of the member who owns this investment. Leave blank to assign it to you.")
        elif key == "notes":
            _add_comment(cell, "Optional free text.")
        width = max(14, min(len(label) + 4, 34))
        ws.column_dimensions[get_column_letter(col)].width = width

    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "C2"
    last_col = get_column_letter(len(headers))
    ws.auto_filter.ref = f"A1:{last_col}1"

    data_rows = rows or []
    for r_idx, row in enumerate(data_rows, start=2):
        for col, (key, _label, kind) in enumerate(headers, start=1):
            if key == "owner_email":
                value = row.get("owner_email")
            elif key in ("name", "invested_amount", "current_value", "start_date", "notes"):
                value = row.get(key)
            else:
                value = (row.get("details") or {}).get(key)
            if key == "start_date" and isinstance(value, str) and value:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d").date()
                except ValueError:
                    pass
            cell = ws.cell(row=r_idx, column=col, value=value)
            cell.font = Font(size=10)
            if kind == "number":
                if key in ("invested_amount", "current_value") or _is_amount_field(type_meta, key):
                    cell.number_format = INR_FORMAT
                elif _is_percent_field(type_meta, key):
                    cell.number_format = PERCENT_FORMAT
            elif kind == "date":
                cell.number_format = DATE_FORMAT

    if rows:
        for col in range(1, len(headers) + 1):
            letter = get_column_letter(col)
            for row_idx in range(2, len(rows) + 2):
                ws.cell(row=row_idx, column=col).alignment = Alignment(vertical="center")

    # Data validation for every input column
    for col, (key, _label, kind) in enumerate(headers, start=1):
        letter = get_column_letter(col)
        rng = f"{letter}2:{letter}{MAX_IMPORT_ROWS}"
        field_meta = next((f for f in type_meta["fields"] if f["key"] == key), None)
        if key == "owner_email":
            continue
        if field_meta and field_meta["input"] in ("select", "boolean"):
            list_name = list_for_field.get((type_meta["key"], key))
            if list_name and list_name in list_ranges:
                dv = DataValidation(type="list", formula1=list_ranges[list_name], allow_blank=True)
                dv.error = "Pick a value from the dropdown list."
                dv.errorTitle = "Invalid choice"
                dv.showErrorMessage = True
                ws.add_data_validation(dv)
                dv.add(rng)
        elif kind == "number":
            dv = DataValidation(type="decimal", operator="greaterThanOrEqual", formula1="0", allow_blank=True)
            dv.error = "Enter a number of zero or more."
            dv.errorTitle = "Invalid number"
            dv.showErrorMessage = True
            ws.add_data_validation(dv)
            dv.add(rng)
        elif kind == "date":
            dv = DataValidation(
                type="date", operator="between", formula1="DATE(1950,1,1)", formula2="DATE(2100,12,31)",
                allow_blank=True,
            )
            dv.error = "Enter a valid date, e.g. 31-03-2026."
            dv.errorTitle = "Invalid date"
            dv.showErrorMessage = True
            ws.add_data_validation(dv)
            dv.add(rng)
    return ws


def _is_amount_field(type_meta, key):
    return key in {"principal", "monthly_amount", "deposit_amount", "premium_amount", "sum_assured",
                   "face_value", "purchase_price", "avg_buy_price", "ltp", "avg_nav", "current_nav",
                   "avg_price", "current_price", "current_value", "invested_amount", "sip_amount",
                   "yearly_contribution", "employee_contribution", "employer_contribution",
                   "registration_charges", "loan_outstanding", "monthly_rent", "fund_value"}


def _is_percent_field(_type_meta, key):
    return key in {"interest_rate", "coupon_rate", "ownership_pct", "annuity_pct"}


def _readme_sheet(wb):
    ws = wb.create_sheet("Read me", 0)
    ws.sheet_properties.tabColor = "4F46E5"
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 34
    ws.column_dimensions["C"].width = 94
    ws.merge_cells("B2:C2")
    title = ws["B2"]
    title.value = "DeepTrack — bulk import template"
    title.font = Font(size=20, bold=True, color="0F172A")
    ws.row_dimensions[2].height = 30
    ws.merge_cells("B3:C3")
    ws["B3"].value = "One row per investment. Use the tab that matches the investment type and pick values from the dropdowns."
    ws["B3"].font = Font(size=11, color=MUTED)
    ws.row_dimensions[3].height = 22

    steps = [
        ("1. Pick the right tab", "There is one tab per instrument type, colour-coded by asset class. Only fill tabs you need."),
        ("2. Fill one row per holding", "Columns marked * are required. Everything else is optional but improves reporting."),
        ("3. Use the dropdowns", "Columns with a small arrow have validated lists based on Indian banks, AMCs, insurers, exchanges and more."),
        ("4. Amounts", "Enter rupees (₹) without commas or currency symbols. Amounts can also be auto-computed from quantity × price fields."),
        ("5. Dates", "Use DD-MM-YYYY, e.g. 31-03-2026. Start date is the purchase or scheme start date."),
        ("6. Owner email", "Enter the email of the member who owns the holding. Leave blank to assign it to the person importing."),
        ("7. Upload", "Save the file and upload it in DeepTrack under Import. You will see a preview before anything is saved."),
    ]
    row = 5
    for heading, body in steps:
        ws.cell(row=row, column=2, value=heading).font = Font(size=11, bold=True, color="312E81")
        cell = ws.cell(row=row, column=3, value=body)
        cell.font = Font(size=11, color="334155")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 34 if len(body) > 95 else 22
        row += 1

    row += 1
    ws.cell(row=row, column=2, value="Asset classes and tabs").font = Font(size=13, bold=True, color="0F172A")
    row += 1
    for cat in fields.CATEGORIES:
        ws.cell(row=row, column=2, value=cat["label"]).font = Font(
            size=11, bold=True, color=cat["color"].lstrip("#").upper()
        )
        types = [t["label"] for t in fields.TYPE_LIST if t["category"] == cat["key"]]
        body = ws.cell(row=row, column=3, value=", ".join(types))
        body.font = Font(size=11, color="334155")
        row += 1

    row += 1
    ws.cell(row=row, column=2, value="Example row (Mutual funds tab)").font = Font(size=13, bold=True, color="0F172A")
    row += 1
    example = [
        ("Investment name", "Parag Parikh Flexi Cap Fund"),
        ("AMC", "Parag Parikh MF"),
        ("Scheme category", "Flexi Cap"),
        ("Plan / Option", "Direct / Growth"),
        ("Units held", "412.665"),
        ("Average NAV / Current NAV", "₹ 62.40 / ₹ 74.18"),
        ("Amount invested", "₹ 25,750.00 (auto-computed if left blank)"),
        ("Owner email", "priya@example.com"),
    ]
    for label, value in example:
        ws.cell(row=row, column=2, value=label).font = Font(size=10, color=MUTED)
        ws.cell(row=row, column=3, value=value).font = Font(size=10, color="0F172A")
        row += 1

    row += 1
    note = ws.cell(row=row, column=2, value="Important")
    note.font = Font(size=12, bold=True, color="B91C1C")
    body = ws.cell(
        row=row, column=3,
        value="Do not rename or reorder the tabs and do not change the header row — the importer relies on both. "
              "Empty rows are ignored. Duplicate holdings are allowed but flagged as a warning in the preview.",
    )
    body.font = Font(size=10, color="334155")
    body.alignment = Alignment(wrap_text=True, vertical="top")
    ws.row_dimensions[row].height = 46
    return ws


def _guide_sheet(wb):
    ws = wb.create_sheet("Field guide", 1)
    ws.sheet_properties.tabColor = "94A3B8"
    ws.sheet_view.showGridLines = False
    headers = ["Tab", "Field", "Required", "Input", "Options / notes"]
    widths = [26, 30, 10, 12, 72]
    for idx, (label, width) in enumerate(zip(headers, widths), start=1):
        cell = ws.cell(row=1, column=idx, value=label)
        _style_header(cell, HEADER_FILL)
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.freeze_panes = "A2"
    row = 2
    for type_meta in fields.TYPE_LIST:
        base = [
            ("name", "Investment name", True, "text", type_meta.get("name_placeholder", "")),
            ("invested_amount", type_meta.get("invested_label", "Amount invested"), True, "number",
             "Rupees, e.g. 150000"),
            ("current_value", type_meta.get("value_label", "Current value"), False, "number",
             "Defaults to the invested amount when blank"),
            ("start_date", "Purchase / start date", False, "date", "DD-MM-YYYY"),
            ("notes", "Notes", False, "text", ""),
            ("owner_email", "Owner email", False, "email", "Blank = the importing member"),
        ]
        entries = list(base) + [
            (fld["key"], fld["label"], bool(fld.get("required")), fld["input"],
             " | ".join(fld["options"]) if fld.get("options") else fld.get("help") or "")
            for fld in type_meta["fields"]
        ]
        for _key, label, required, kind, extra in entries:
            values = [
                type_meta["sheet"], label, "Yes" if required else "", kind, extra,
            ]
            for col, value in enumerate(values, start=1):
                cell = ws.cell(row=row, column=col, value=value)
                cell.font = Font(size=9, color="334155")
                cell.alignment = Alignment(vertical="top", wrap_text=col == 5)
            row += 1
    return ws


def _lists_sheet(wb, lists):
    ws = wb.create_sheet("_lists")
    ws.sheet_state = "hidden"
    for idx, item in enumerate(lists, start=1):
        letter = get_column_letter(idx)
        ws.cell(row=1, column=idx, value=item["key"]).font = Font(bold=True, size=9, color="FFFFFF")
        ws.cell(row=1, column=idx).fill = PatternFill("solid", fgColor="334155")
        for r, option in enumerate(item["options"], start=2):
            ws.cell(row=r, column=idx, value=option).font = Font(size=9)
        ws.column_dimensions[letter].width = 24
    return ws


def build_workbook(rows_by_type=None) -> Workbook:
    lists, list_for_field = _collect_lists()
    wb = Workbook()
    wb.remove(wb.active)
    _readme_sheet(wb)
    _guide_sheet(wb)
    list_ranges = {}
    for item in lists:
        idx = lists.index(item) + 1
        letter = get_column_letter(idx)
        list_ranges[item["key"]] = f"_lists!${letter}$2:${letter}${len(item['options']) + 1}"
    for type_meta in fields.TYPE_LIST:
        _write_sheet(wb, type_meta, list_ranges, list_for_field, (rows_by_type or {}).get(type_meta["key"], []))
    _lists_sheet(wb, lists)
    wb.active = 0
    return wb


def _to_bytes(wb) -> bytes:
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


def template_bytes() -> bytes:
    return _to_bytes(build_workbook())


def export_bytes(rows: list[dict]) -> bytes:
    grouped: dict[str, list[dict]] = {}
    for row in rows:
        grouped.setdefault(row["type"], []).append(row)
    return _to_bytes(build_workbook(grouped))


def _build_header_map(type_meta) -> dict:
    mapping = {}
    for fld in type_meta["fields"]:
        mapping[_norm(fld["label"])] = fld["key"]
        mapping[_norm(_header(fld))] = fld["key"]
        mapping[_norm(fld["key"])] = fld["key"]
    mapping.update({
        "investment name": "name",
        "name": "name",
        "amount invested": "invested_amount",
        "current value": "current_value",
        "purchase start date": "start_date",
        "start date": "start_date",
        "notes": "notes",
        "owner email": "owner_email",
        "owner": "owner_email",
    })
    for key, label, _kind in COMMON_EXCEL:
        mapping[_norm(label)] = key
    mapping.update(ALIASES)
    return mapping


def parse_workbook(stream, members: list[dict], default_owner_id: int, existing_keys: set | None = None):
    """Parse an uploaded workbook. Returns (preview_rows, payloads, warnings)."""
    try:
        wb = load_workbook(stream, data_only=True, read_only=False)
    except Exception as exc:  # noqa: BLE001
        raise ValueError("Could not read this file. Upload an .xlsx template downloaded from DeepTrack.") from exc

    by_email = {}
    for member in members:
        by_email[member["email"].lower()] = member
    default_owner = next((m for m in members if m["id"] == default_owner_id), None)
    default_owner_name = default_owner["name"] if default_owner else "You"

    preview, payloads, sheet_warnings = [], [], []
    recognised = 0
    for ws in wb.worksheets:
        type_key = fields.SHEETS.get(ws.title)
        if not type_key:
            continue
        recognised += 1
        type_meta = fields.TYPES[type_key]
        header_map = _build_header_map(type_meta)
        headers = [header_map.get(_norm(cell.value)) for cell in ws[1]]
        if "name" not in headers:
            sheet_warnings.append(f"'{ws.title}' skipped: header row not recognised.")
            continue
        for row_idx, row in enumerate(
            ws.iter_rows(min_row=2, max_row=min(ws.max_row, MAX_IMPORT_ROWS + 1), values_only=True), start=2
        ):
            if row is None or all(cell is None or str(cell).strip() == "" for cell in row):
                continue
            raw = {}
            for key, value in zip(headers, row):
                if key and value is not None and str(value).strip() != "":
                    raw[key] = value
            if not raw:
                continue

            payload = {"type": type_key}
            payload.update({k: v for k, v in raw.items() if k != "owner_email"})

            owner_email = str(raw.get("owner_email") or "").strip().lower()
            if owner_email:
                member = by_email.get(owner_email)
                if member:
                    payload["owner_id"] = member["id"]
                    owner_error = None
                    owner_name = member["name"]
                else:
                    payload["owner_id"] = None
                    owner_error = f"No member with email {owner_email}"
                    owner_name = owner_email
            else:
                payload["owner_id"] = default_owner_id
                owner_error = None
                owner_name = default_owner_name

            data, errors = fields.validate_investment(payload)
            if owner_error:
                errors["owner_email"] = owner_error

            name = str(raw.get("name") or "").strip()
            preview_row = {
                "sheet": ws.title,
                "row": row_idx,
                "type": type_key,
                "type_label": type_meta["label"],
                "name": name or "(no name)",
                "owner": owner_name,
                "invested": data.get("invested_amount") if data else None,
                "current": data.get("current_value") if data else None,
                "errors": errors,
                "warnings": [],
            }
            if not errors:
                derived_invested, derived_value = fields._derive_values(type_meta, data.get("details") or {})
                if "invested_amount" not in raw and derived_invested is not None:
                    preview_row["warnings"].append("Amount invested computed from the fields provided")
                if "current_value" not in raw:
                    if derived_value is not None:
                        preview_row["warnings"].append("Current value computed from the fields provided")
                    elif data.get("current_value") == data.get("invested_amount"):
                        preview_row["warnings"].append("Current value defaults to invested amount")
                key3 = (data["owner_id"], data["type"], (data["name"] or "").strip().lower())
                if existing_keys and key3 in existing_keys:
                    preview_row["warnings"].append("A holding with this name already exists for this member")
            preview.append(preview_row)
            payloads.append({"preview": preview_row, "payload": payload, "valid": not errors})

    if recognised == 0:
        raise ValueError(
            "No DeepTrack tabs found. Use a template downloaded from DeepTrack and keep the tab names unchanged."
        )

    counts = {}
    for item in payloads:
        if not item["valid"]:
            continue
        data, _ = fields.validate_investment(item["payload"])
        key = (data["owner_id"], data["type"], (data["name"] or "").strip().lower())
        counts[key] = counts.get(key, 0) + 1
    for item in payloads:
        if not item["valid"]:
            continue
        data, _ = fields.validate_investment(item["payload"])
        key = (data["owner_id"], data["type"], (data["name"] or "").strip().lower())
        if counts[key] > 1:
            item["preview"]["warnings"].append("Duplicate of another row in this file")

    return preview, payloads, sheet_warnings
