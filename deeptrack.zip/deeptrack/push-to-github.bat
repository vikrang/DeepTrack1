@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set REPO=%~1
if "%REPO%"=="" (
  echo.
  echo   Create an empty repo first at https://github.com/new
  echo   ^(name it deeptrack, no README^), then paste its URL below.
  echo.
  set /p REPO=Repo URL ^(https://github.com/USER/REPO.git^): 
)
if "%REPO%"=="" (
  echo   No repo URL given. Nothing to do.
  pause
  exit /b 1
)

set NAME=
for /f "delims=" %%i in ('git config --global user.name 2^>nul') do set NAME=%%i
if "!NAME!"=="" (
  set /p NAME=Your name for git commits: 
  git config --global user.name "!NAME!"
)

set EMAIL=
for /f "delims=" %%i in ('git config --global user.email 2^>nul') do set EMAIL=%%i
if "!EMAIL!"=="" (
  set /p EMAIL=Your GitHub email: 
  git config --global user.email "!EMAIL!"
)

if not exist ".git" git init -b main
git add -A
git commit -m "DeepTrack" >nul 2>&1
git remote remove origin >nul 2>&1
git remote add origin %REPO%

echo.
echo   Pushing to %REPO% ...
echo.
git push -u origin main

echo.
echo   If the push was rejected because the repo already has commits, run:
echo     git pull --rebase origin main
echo     git push -u origin main
echo.
pause
